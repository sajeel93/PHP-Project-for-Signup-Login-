

<?php 

	session_start();

  if(isset($_POST['submit'])) {

$to    = "sajeel.ahmed786@gmail.com";
$subject = "New Email from client";

$Fname  = $_POST['first_name'];
$Lname  = $_POST['last_name'];
$phone  = $_POST['phone'];
$email  = $_POST['user_email'];
$msg    = $_POST['message'];

$message = $Fname . " " . "\n\n" . $Lname . " " . "\n\n" . $phone . " " . "\n\n" . $email . " " . "\n\n" . $msg;
$header  = "From:" . $Fname;


mail($to, $subject, $message, $header);

echo "Mail Sent. Thank you " . $Fname . " we will contact you shortly.";
echo $message;

}

?>

<?php

  include("includes/header.php");

?>


<!--Contect-->
<div class="container">
  <h2>Contact form</h2>
  
  <form id="contact-form" method="post" action="" role="form">

    <div class="messages"></div>

    <div class="controls">

        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <label for="form_name">Firstname *</label>
                    <input id="form_name" type="text" name="first_name" class="form-control" placeholder="Please enter your firstname *" required="required" data-error="Firstname is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label for="form_lastname">Lastname *</label>
                    <input id="form_lastname" type="text" name="last_name" class="form-control" placeholder="Please enter your lastname *" required="required" data-error="Lastname is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <label for="form_email">Email *</label>
                    <input id="form_email" type="email" name="user_email" class="form-control" placeholder="Please enter your email *" required="required" data-error="Valid email is required.">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="form-group">
                    <label for="form_phone">Phone</label>
                    <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Please enter your phone">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="form_message">Message *</label>
                    <textarea id="form_message" name="message" class="form-control" placeholder="Message for me *" rows="4" required="required" data-error="Please,leave us a message."></textarea>
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="col-md-12">
                <input type="submit" name="submit" class="btn btn-success btn-send" value="Send message">
            </div>
        </div>
        
    </div>

  </form>


</div>


<?php

  include("includes/footer.php");

?>