

<?php 

	session_start();

	include("includes/Users.php");

    $user = new User;

	if(isset($_POST['submit'])) {

		$login = $user->login();

		if($login) {

			header("location:home.php");
		}
		else{

			echo "Wrong Email & password";
		}
	}

?>


<?php

  include("includes/header.php");

?>

<script type="text/javascript">
	
	function submin_login() {

		var form = document.login;

		if (form.user_email.value == "") {

			alert("Enter Email");
			return false;
		}

		if(form.user_password.value == "") {

			alert("Enter Password");
			return false;
		}
	}
</script>

<!--Contect-->
<div class="container">
  <h2>Login form</h2>
  <form class="form-horizontal" role="form" action="" method="post" name="login">

	
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-6">
        <input type="email" class="form-control" id="email" name="user_email" placeholder="Enter email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-6">
        <input type="password" class="form-control" id="pwd" name="user_password" placeholder="Enter password">
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <div class="checkbox">
          <label><input type="checkbox"> Remember me</label>
        </div>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default" onclick="submin_login()">Submit</button>
      </div>
    </div>
  </form>
</div>


<?php

  include("includes/footer.php");

?>