<?php


	define('DB_SERVER', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'second_db');

class User{

		public $conn;
		public function __construct(){
			$this->conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		
			if(mysqli_connect_errno()) {
	 
				echo "Error: Could not connect to database.";
	 
			exit;
 
			}
		}


		public function signup() {

			$Fname    = $_POST['first_name'];
			$Lname    = $_POST['last_name'];
			$Contact  = $_POST['user_contact'];
			$email    = $_POST['user_email'];
			$password = $_POST['user_password'];

			$query = "SELECT * FROM users WHERE user_email = '$email' AND user_password='$password'";

			//checking if the username or email is available in db
			$check 		= mysqli_query($this->conn, $query);
			$count_row  = mysqli_num_rows($check);

			if ($count_row == 0) {


				$query2 = "INSERT INTO users(first_name, last_name, user_contact, user_email, user_password) VALUES('$Fname', '$Lname', '$Contact', '$email', '$password')";

				$result = mysqli_query($this->conn, $query2);

				return $result;
			}

			else {
				return false;
			}
		}

		public function login() {

			
			$email    = $_POST['user_email'];
			$password = $_POST['user_password'];

			$query3 = "SELECT * FROM users WHERE user_email = '$email' AND user_password = '$password' ";

			$result 	= mysqli_query($this->conn, $query3);
			$user_data  = mysqli_fetch_array($result);
			$count_row  = mysqli_num_rows($result);

			if($count_row == 1){

				

				$_SESSION['login']    = true;
				$_SESSION['id']       = $user_data['id'];
				$_SESSION['email']    = $user_data['user_email'];
				$_SESSION['password'] = $user_data['user_password'];
				return true;
			}
			
			else{

				return false;
			}	

		}

		public function session() {

			return $_SESSION['login'];
		}

		/*** for showing the username or fullname ***/
    	public function get_fullname($uid){

    		//$uid = $_SESSION['id'];
			
    		$sql3="SELECT * FROM users WHERE id = $uid";
	        $result = mysqli_query($this->conn,$sql3);
	        $user_data = mysqli_fetch_array($result);
	        echo $user_data['first_name'] . " " . $user_data['last_name'];

    	}

    	public function logout() {
	        $_SESSION['login'] = FALSE;
	        session_destroy();
	    }

}

?>