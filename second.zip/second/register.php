

<?php

session_start();

  include("includes/Users.php");

  $user = new User;
  
  if (isset($_POST['submit'])) {

    $register = $user->signup();

    if($register) {

      echo "Registration Successfull";
    }

    else{

      echo "Registration failed. Email or Username already exits please try again";
    }
    
  }


?>

<script type="text/javascript">
  
  function submit_reg(){

    var form = document.registration;

    if(form.first_name.value == "") {

      alert("Enter first Name");
      return false;
    }

    else if(form.last_name.value == "") {

      alert("Enter Last Name");
      return false;
    }

    else if(form.user_contact.value == "") {

      alert("Enter contact no");
      return false;
    }

    else if(form.user_email.value == "") {

      alert("Enter Email");
      return false;
    }
    else if(form.user_password.value == "") {

      alert("Enter Password");
      return false;
    }
    
  }
</script>



<?php

  include("includes/header.php");

?>



    
<!--Contect-->
<div class="container">
  <h2>Register form</h2>
  <form class="form-horizontal" role="form" action="" method="post" name="registration">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">First Name:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="first" name="first_name" placeholder="First Name">
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="email">Last Name:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="last" name="last_name" placeholder="Last Name">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Contact:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="last" name="user_contact" placeholder="Mobile No">
      </div>
    </div>
	
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-6">
        <input type="email" class="form-control" id="email" name="user_email" placeholder="Enter email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Password:</label>
      <div class="col-sm-6">
        <input type="password" class="form-control" id="pwd" name="user_password" placeholder="Enter password">
      </div>
    </div>
   
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default" onclick="submit_reg()">Submit</button>
      </div>
    </div>
  </form>
</div>



<?php

  include("includes/footer.php");

?>


   

